<?php
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="256x256" href="img/icons/corona.ico">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fredoka+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
    <title>SALVIO</title>
</head>

<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top " id="mainNav">
        <div class="container-fluid">
            <a class="navbar-brand" href="page-top"><b class="name">SALVIO</b></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link js-scroll-trigger" href="home.php">Home <span
                                class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Dropdown
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="HLP.html">Health Live pattern</a>
                            <a class="dropdown-item" href="prevent.html">Prevent the virus</a>
                            <a class="dropdown-item" href="survey.php">survey</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="contact.php">Contact</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="index.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <br><br>
            <h1 class="display-4">LET'S STOP CORONA FROM YOURSELF</h1>
            <p class="lead">"Big results start from small steps"</p>
        </div>
    </div>

    <nav class="navbar navbar-light bg-light ml-3">
        <div class="content ">
            <h2>WHAT IS CORONA?</h2>
            <P id="1"> Corona or COVID-19 is a virus that attacks the human respiratory system.
                This virus first appeared in China in December 2019.
                Corona virus appears with several different symptoms in the patient's body.
                However, in general, the symptoms of the Corona virus are flu, fever, cough, to shortness of breath.
                Check interactive map<a target="_blank"
                    href="https://www.arcgis.com/apps/opsdashboard/index.html#/bda7594740fd40299423467b48e9ecf6">
                    <b>here</b></a>.
            </P>
            <br>
            <h2>HOW IS COVID-19 SPREAD?</h2>
            <P id="2" class="d-flex justify-content-between">According to the World Health Organization (WHO),
                the way the corona virus spreads or COVID-19 is through tiny droplets that come out of the nose or mouth
                when those infected with the virus sneeze or cough. The drops then land on objects or surfaces touched
                by healthy people.
                Then this healthy person touches their eyes, nose or mouth. Corona virus can also spread when small
                droplets are inhaled
                by healthy people when in close proximity to infected corona.</P>
            <br>
            <h2 id="3">HOW IS COVID-19 DIAGNOSED?</h2>
            <p>Diagnosis for this virus may be difficult with just a physical examination because mild cases of COVID-19
                may look similar to the flu or a cold. To ensure that the symptoms experienced are actually caused by
                COVID-19,
                laboratory tests need to be carried out such as taking blood and sputum samples, performing a swab in
                the throat and
                chest X-ray to see if there is fluid in the lungs. You will most likely get COVID-19 if you experience
                severe symptoms,
                live with certain health conditions, such as (Diabetes, heart disease, chronic lung disease,
                immunosuppressive therapy),
                and Work in environmental health care.</b></p>
            <br>
            <h2 id="4">HOW DO YOU PROTECT YOURSELF FROM THIS CORONAVIRUS?</h2>
            <P>It is important to understand that this virus is spread mainly from person to person. If you are
                infected,
                there are several ways you can do to avoid close contact with others, such as wearing a mask
                when leaving the house because the corona virus that attacks the respiratory tract and its spread
                through the air
                can be prevented by using a mask to cover the nose and mouth. Use tissue when sneezing or coughing. Keep
                immunity by exercising
                because a weak immune system will make the virus attack the body more easily. Routine health check
                because every disease
                can be cured and prevented if we know it from the beginning. Avoid foods from wild animals, according to
                WHO,
                the corona virus is a zoomatic or a virus that is transmitted from animals to humans. The hobby of the
                Wuhan people
                consuming bats is thought to be the origin of this fast-growing virus there. Always maintain hand
                hygiene by washing hands at
                any time after shaking hands with others.</b></P>
            <br><br>
            <br>
            <h2 id="5">HOW FATAL IS THIS CORONA VIRUS?</h2>
            <P>In just two months since it was discovered in China, the corona virus spread throughout the world, except
                Antarctica.
                The disease caused by a virus called COVID-19 now has a higher death rate than the flu . COVID-19 is
                indeed deadly.
                But the scientific community has not yet determined the fatality rate of the corona virus amid
                increasing numbers of patients in many countries,
                including the U.S. The latest estimates from the World Health Organization (WHO) show that nearly 3.4
                percent of COVID-19 patients worldwide have died.
                In China, with 80,422 confirmed cases, health authorities announced the death rate had risen to 2.3
                percent.
                Most people who die from the virus are elderly patients and those who have pre-existing health problems.
                People infected with corona virus aged 80 years and older have a high mortality rate of 14.8 percent.
                Whereas, patients aged between 70 and 79 years have a mortality rate of 8 percent. In Italy,
                all patients who have died of COVID-19 are over 60 years old.<br><br>

                According to WHO, the country currently has the highest mortality rate in Europe due to the corona
                virus,
                with 80 deaths recorded. However, health authorities and scientists note that the number of infections
                and deaths reported may be inaccurate.
                It is also difficult to calculate deaths related to the new corona virus, because it can take days to
                weeks for severely ill patients to die of COVID-19.
                The researchers said in a recent report in Swiss Medical Weekly, that authorities must calculate
                mortality by dividing the number of known
                infections from one or two weeks before. However, another problem is that epidemiologists believe the
                total number of infections is underestimated
                in some countries. That's because people with few or mild symptoms, may never go to a clinic or
                hospital, so they don't count.<br><br>

                COVID-19 effects can cause death. But in some countries, coronavirus disease can kill more people
                because of poor access to appropriate medical care.
                Reports indicate that the problem with the medical system in Wuhan, China, where the outbreak began,
                contributed to many deaths.
                The WHO said in a February report, the case fatality ratio in Wuhan was 5.8 percent compared to other
                countries which was only 0.7 percent.
                In the U.S., testing for novel coronaviruses is also inadequate, which makes it difficult to diagnose
                patients and get the right number of cases,
                according to Marc Lipsitch, director of the infectious disease dynamics center at Harvard T.H Chan
                School of Public Health.
                "All these numbers are very volatile and very speculative,"</b></P>
            <br><br>
            <img src="img/covid2.jpeg" class="image">
            <br><br><br>
            <div class="company" id="">
                <div class="footer-copyright text-center py-3">
                    <h6>© 2020 Copyright:<b class="name">SALVIO</b></h6>
                </div>
            </div>
        </div>
    </nav>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
</body>

</html>