<?php 
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--===========================================================================================================-->
    <link rel="icon" type="image/png" sizes="256x256" href="img/icons/corona.ico">
    <!--===========================================================================================================-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--===========================================================================================================-->
    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fredoka+One&display=swap" rel="stylesheet">
    <!--===========================================================================================================-->
    <link rel="stylesheet" href="css/index.css">
    <!--===========================================================================================================-->
    <title>SALVIO</title>
</head>

<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top " id="mainNav">
        <div class="container-fluid">
            <a class="navbar-brand" href="page-top"><b class="name">SALVIO</b></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link js-scroll-trigger" href="index.php">Home <span
                                class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Dropdown
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#1">How corona spread</a>
                            <a class="dropdown-item" href="#2">How is corona Diagnosed</a>
                            <a class="dropdown-item" href="#3">How to protect yourself</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#4">What is <b class="name">SALVIO</b></a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#5">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="signup.php">Signup</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <br><br>
            <h1 class="display-4">LET'S STOP CORONA FROM YOURSELF</h1>
            <p class="lead">"Big results start from small steps"</p>
        </div>
    </div>

    <nav class="navbar navbar-light bg-light ml-3">
        <div class="content ">
            <h2>WHAT IS CORONA?</h2>
            <P id="1"> Corona is the disease caused by the new coronavirus that
                emerged in China in December
                2019.COVID-19
                symptoms
                include cough, fever and shortness of breath. COVID-19 can be severe, and some cases have caused
                death.Check interactive map<a target="_blank"
                    href="https://www.arcgis.com/apps/opsdashboard/index.html#/bda7594740fd40299423467b48e9ecf6">
                    <b>here</b></a>.
            </P>
            <br>
            <h2>HOW IS COVID-19 SPREAD?</h2>
            <P id="2" class="d-flex justify-content-between">COVID-19 can be passed from person to person through
                droplets from coughs and sneezes. COVID-19
                has been detected in people all over the world, and is considered a pandemic.The spread of this new
                coronavirus
                is being monitored by the Centers for Disease Control (CDC), the WorldHealth Organization and health
                organizations.</P>
            <br>
            <h2 id="3">HOW IS COVID-19 DIAGNOSED?</h2>
            <p>Diagnosis may be difficult with only a physical exam because mild cases of COVID-19 may appear similar to
                the flu or a bad cold. A laboratory test can confirm the diagnosis.You are most likely to get COVID-19
                if you are <b>experiencing severe symptoms</b>,<b>living with certain health conditions</b>, like
                (Diabetes, Heart disease, Chronic lung disease, Immunosuppressive therapy), and <b>Working in a health
                    care environment</b></p>
            <br>
            <h2 id="4">HOW DO YOU PROTECT YOURSELF FROM THIS CORONAVIRUS?</h2>
            <P>It’s crucial to practice good hygiene, respiratory etiquette and social distancing. It's Important to
                understand that this virus spread mainly from person to person.If you are infected, there are some way
                that you can take to avoid close contact with others, such as <b>Stay home as much as possible and
                    reduce visitors,Stay at least six feet away from others in public places,Avoid people who appear
                    sick,Go grocery shopping and run errands during off-peak times.Wash your hands with soap and water
                    frequently and thoroughly for at least 20 seconds,Avoid touching your eyes, nose or mouth,
                    especially with unwashed hands,Wear a mask if you are caring for someone who has respiratory
                    symptoms, andClean counters, door knobs, phones and tablets frequently, using disinfectant cleaners
                    or wipes.</b></P>
            <br><br>
            <div class="company" id="">
                <h2 id="">WHAT IS <b class="name">SALVIO</b>?</h2>
                <p><b class="name">SALVIO</b>(<i>Latin</i> : healing,
                    health) is an website that inform you about Corona (COVID-19) generally.Not only
                    that, in this website you also can see the spread of Corona.we have a vision that is "giving more
                    benefits than you imagine".
                    a vision that will bring us to provide the best for you. The best in service want service.
                    We will realize this vision through our mission of "providing the latest information to our web
                    users".
                    We will continue to develop ourselves to be the best. We believe that to be the best, we must
                    compete for ourselves.
                    With that, we will always serve and provide information to our web users.</p>
                <p>On our website, we provide the latest information about the corona virus or COVID-19.
                    Here we also provide a survey to find out whether we are included in the characteristics of people
                    who are exposed to this virus or not, and also there is an interactive map Check on this website
                    where on
                    the map we can see how the development of covid-19 in countries that are infected with this
                    virus that exists throughout the world.</p>
                <br>
                <h2 id="">WHY YOU MUST USE THIS WEBSITE?</h2>
                <p>
                    <ul>
                        <li>Healthy Lifestyles</li>
                        <li>Live Tracking of COVID-19</li>
                        <li>Prevention</li>
                        <li>Check Your Condition</li>
                    </ul>
                </p>
            </div>
            <img src="img/img2.png" alt="be kind, be clean, take care" class="image">
            <br><br><br>
            <div class="contact" id="5">
                <h4>OUR CONTACT</h4>
                <a href="#"><b>Instagram</b></a>
                <br>
                <a href="#"><b>E-mail</b></a>
            </div>
            <div class="footer-copyright text-center py-3">
                <h6>© 2020 Copyright: <b class="name">SALVIO</b></h6>
            </div>
        </div>
    </nav>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
</body>

</html>