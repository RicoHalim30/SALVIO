<?php
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="256x256" href="img/icons/corona.ico">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fredoka+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
    <title>Contact</title>
</head>

<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top " id="mainNav">
        <div class="container-fluid">
            <a class="navbar-brand" href="page-top"><b class="name">SALVIO</b></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link js-scroll-trigger" href="home.php">Home <span
                                class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Dropdown
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="HLP.html">Health Live pattern</a>
                            <a class="dropdown-item" href="prevent.html">Prevent the virus</a>
                            <a class="dropdown-item" href="survey.php">survey</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="contact.php">Contact</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="index.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <br><br>
            <h1 class="display-4">LET'S STOP CORONA FROM YOURSELF</h1>
            <p class="lead">"Big results start from small steps"</p>
        </div>
    </div>

    <nav class="navbar navbar-light bg-light ml-3">
        <div class="content ">
            <h2>WORLD HEALTH ORGANIZATION</h2>
            <P id="1"> The World Health Organization (WHO) is a specialized agency of the United Nations responsible for
                international public health. Let's click<a target="_blank" href="https://www.who.int/">
                    <b>here</b></a>.</p>
            <h2>CENTERS FOR DISEASE CONTROL AND PREVENTION</h2>
            <p>The Centers for Disease Control and Prevention (CDC) is the leading national public health institute of
                the
                United States. It is a United States federal agency, under the Department of Health and Human
                Services, and is headquartered in Atlanta, Georgia.Let's click<a target="_blank"
                    href="https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/how-covid-spreads.html">
                    <b>here</b></a>.</p>
            <br><br><br>
            <img src="img/img2.png" alt="be kind, be clean, take care" class="image">
            <div class="contact" id="5">
                <h4>OUR CONTACT</h4>
                <a href="#"><b>Instagram</b></a>
                <br>
                <a href="#"><b>E-mail</b></a>
            </div>
            <div class="footer-copyright text-center py-3">
                <h6>© 2020 Copyright:<b class="name">SALVIO</b></h6>
            </div>
        </div>
    </nav>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
</body>

</html>